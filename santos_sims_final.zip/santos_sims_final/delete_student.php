<?php
require_once 'config/database.php';
require_once 'config/session.php';

// Require login for this page
requireLogin();

$database = new Database();
$db = $database->getConnection();

// Get student ID from URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: dashboard.php");
    exit();
}

// Delete student
$query = "DELETE FROM students WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(":id", $id);

if ($stmt->execute()) {
    $_SESSION['success'] = "Student deleted successfully!";
} else {
    $_SESSION['error'] = "Failed to delete student. Please try again.";
}

header("Location: dashboard.php");
exit(); 