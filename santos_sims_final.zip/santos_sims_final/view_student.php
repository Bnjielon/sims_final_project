<?php
require_once 'config/database.php';
require_once 'config/session.php';

// Require authentication
requireAuth();

$database = new Database();
$db = $database->getConnection();

// Get student ID from URL
if (!isset($_GET['id'])) {
    header('Location: dashboard.php');
    exit();
}

$id = (int)$_GET['id'];

// Get student data with course information
$query = "SELECT s.*, c.course_code, c.course_name, u.username as created_by_username 
          FROM students s 
          LEFT JOIN courses c ON s.course_id = c.course_id 
          LEFT JOIN users u ON s.created_by = u.id 
          WHERE s.id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(":id", $id);
$stmt->execute();

if ($stmt->rowCount() == 0) {
    header('Location: dashboard.php');
    exit();
}

$student = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student - Student Information System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/nav.php'; ?>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h3 class="card-title">Student Details</h3>
                            <div>
                                <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="btn btn-warning">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                <a href="dashboard.php" class="btn btn-secondary">
                                    <i class="bi bi-arrow-left"></i> Back
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h5 class="text-muted mb-3">Personal Information</h5>
                                <table class="table table-borderless">
                                    <tr>
                                        <th style="width: 150px;">Student ID:</th>
                                        <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Full Name:</th>
                                        <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Email:</th>
                                        <td><?php echo htmlspecialchars($student['email']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Phone:</th>
                                        <td><?php echo htmlspecialchars($student['phone'] ?: 'Not provided'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Address:</th>
                                        <td><?php echo htmlspecialchars($student['address'] ?: 'Not provided'); ?></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h5 class="text-muted mb-3">Academic Information</h5>
                                <table class="table table-borderless">
                                    <tr>
                                        <th style="width: 150px;">Course:</th>
                                        <td>
                                            <?php 
                                            if ($student['course_code']) {
                                                echo htmlspecialchars($student['course_code'] . ' - ' . $student['course_name']);
                                            } else {
                                                echo '<span class="text-muted">Not assigned</span>';
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Year Level:</th>
                                        <td><?php echo $student['year_level']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status:</th>
                                        <td>
                                            <span class="badge bg-<?php echo $student['status'] == 'active' ? 'success' : 'danger'; ?>">
                                                <?php echo ucfirst($student['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <h5 class="text-muted mb-3">Record Information</h5>
                                <table class="table table-borderless">
                                    <tr>
                                        <th style="width: 150px;">Created By:</th>
                                        <td><?php echo htmlspecialchars($student['created_by_username']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Created At:</th>
                                        <td><?php echo date('F d, Y h:i A', strtotime($student['created_at'])); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Last Updated:</th>
                                        <td><?php echo date('F d, Y h:i A', strtotime($student['updated_at'])); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 