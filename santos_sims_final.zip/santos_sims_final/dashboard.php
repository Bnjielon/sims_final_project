<?php
require_once 'config/database.php';
require_once 'config/session.php';

// Require authentication
requireAuth();

$database = new Database();
$db = $database->getConnection();

// Get search query
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build the query with search condition
$query = "SELECT s.*, c.course_code, c.course_name 
          FROM students s 
          LEFT JOIN courses c ON s.course_id = c.course_id";

if (!empty($search)) {
    $query .= " WHERE s.student_id LIKE :search 
                OR s.first_name LIKE :search 
                OR s.last_name LIKE :search 
                OR s.email LIKE :search";
}

$query .= " ORDER BY s.created_at DESC";

$stmt = $db->prepare($query);

if (!empty($search)) {
    $search_param = "%$search%";
    $stmt->bindParam(":search", $search_param);
}

$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/nav.php'; ?>

    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h3 class="card-title">Student List</h3>
                            <form class="d-flex" method="GET" action="">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="search" 
                                           placeholder="Search ID, name, or email" 
                                           value="<?php echo htmlspecialchars($search); ?>">
                                    <button class="btn btn-dark" type="submit">
                                        <i class="bi bi-search"></i> Search
                                    </button>
                                    <?php if (!empty($search)): ?>
                                        <a href="dashboard.php" class="btn btn-secondary">
                                            <i class="bi bi-x-circle"></i> Clear
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (empty($students)): ?>
                            <div class="alert alert-info">
                                <?php echo !empty($search) ? 'No students found matching your search.' : 'No students found.'; ?>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover align-middle">
                                    <thead class="table-dark">
                                        <tr>
                                            <th class="align-middle" style="width: 120px;">
                                                <i class="bi bi-person-badge me-1"></i> Student ID
                                            </th>
                                            <th class="align-middle" style="width: 200px;">
                                                <i class="bi bi-person me-1"></i> Name
                                            </th>
                                            <th class="align-middle" style="width: 200px;">
                                                <i class="bi bi-envelope me-1"></i> Email
                                            </th>
                                            <th class="align-middle" style="width: 250px;">
                                                <i class="bi bi-mortarboard me-1"></i> Course
                                            </th>
                                            <th class="align-middle" style="width: 100px;">
                                                <i class="bi bi-123 me-1"></i> Year Level
                                            </th>
                                            <th class="align-middle" style="width: 100px;">
                                                <i class="bi bi-circle me-1"></i> Status
                                            </th>
                                            <th class="align-middle" style="width: 200px;">
                                                <i class="bi bi-gear me-1"></i> Actions
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($students as $student): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                                <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                                <td><?php echo htmlspecialchars($student['email']); ?></td>
                                                <td>
                                                    <?php 
                                                    if ($student['course_code']) {
                                                        echo htmlspecialchars($student['course_code'] . ' - ' . $student['course_name']);
                                                    } else {
                                                        echo '<span class="text-muted">Not assigned</span>';
                                                    }
                                                    ?>
                                                </td>
                                                <td class="text-center"><?php echo $student['year_level']; ?></td>
                                                <td class="text-center">
                                                    <span class="badge bg-<?php echo $student['status'] == 'active' ? 'success' : 'danger'; ?>">
                                                        <?php echo ucfirst($student['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <a href="view_student.php?id=<?php echo $student['id']; ?>" class="btn btn-sm btn-info">
                                                            <i class="bi bi-eye"></i> View
                                                        </a>
                                                        <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="btn btn-sm btn-warning">
                                                            <i class="bi bi-pencil"></i> Edit
                                                        </a>
                                                        <a href="delete_student.php?id=<?php echo $student['id']; ?>" 
                                                           class="btn btn-sm btn-danger"
                                                           onclick="return confirm('Are you sure you want to delete this student?')">
                                                            <i class="bi bi-trash"></i> Delete
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 