<?php
// Get current page for active state
$current_page = basename($_SERVER['PHP_SELF']);
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="login.php">
            <img src="images/ntc.jpg" alt="NTC Logo" height="40" class="me-3">
            <b>NTC - Student Information System</b>
        </a>
    </div>
</nav>
    
    