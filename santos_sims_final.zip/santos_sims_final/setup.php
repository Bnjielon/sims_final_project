<?php
require_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if admin already exists
$query = "SELECT id FROM users WHERE role = 'admin'";
$stmt = $db->prepare($query);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    die("Admin user already exists. Please delete this file for security.");
}

// Create admin user
$username = "admin";
$password = "admin123"; // You should change this password immediately after first login
$email = "admin@example.com";
$role = "admin";

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$query = "INSERT INTO users (username, password, email, role) VALUES (:username, :password, :email, :role)";
$stmt = $db->prepare($query);

$stmt->bindParam(":username", $username);
$stmt->bindParam(":password", $hashed_password);
$stmt->bindParam(":email", $email);
$stmt->bindParam(":role", $role);

if ($stmt->execute()) {
    echo "Admin user created successfully!<br>";
    echo "Username: admin<br>";
    echo "Password: admin123<br>";
    echo "<strong>Please delete this file after first login and change the admin password!</strong>";
} else {
    echo "Error creating admin user.";
}
?> 